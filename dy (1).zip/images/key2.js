﻿//kb('.username','.password');
function kb(user,pass){
	var node,index;
	var html = '<style>*{margin:0;padding:0}body,html{font-size:62.5%;font-family:-apple-system-font,Helvetica Neue,sans-serif}.kb_jp{width:100%;max-width:800px;background:#cfd3dc;padding-top:2%;font-size:0;position:fixed;bottom:0;left:0;display:none}.uls{margin-bottom:1%}.uls .key{width:6%;margin:1%;padding:3% 1%;background:#fff;float:left;border-radius:5px;box-shadow:0 2px 1px #a0a0a0;list-style-type:none;font-size:2.0rem}.uls .key,.ulscen{text-align:center}.ulscen .key{display:inline-block;float:none}.clear{clear:both}.ulbot .key:nth-child(1){width:21%;background:#acafbe}.ulbot .key:nth-child(2){width:46%}.ulbot .key:nth-child(3){width:21%;background:#acafbe}.ul5 .key{width:10%}.kb_co{left:0;top:0;width:300px;height:52px;position: absolute;}.key:active{background:#aeb1c0}.kb_del,.kb_sj{width:11%;background:#acafbe;margin:1%;padding:3% 1%;float:left;border-radius:5px;box-shadow:0 2px 1px #a0a0a0;list-style-type:none;text-align:center;font-size:2.0rem}.kb_foot{width:21%;background:#acafbe}.kb_foot,.kb_ok,.kb_space{display:inline-block;float:none;margin:1%;padding:3% 1%;border-radius:5px;box-shadow:0 2px 1px #a0a0a0;list-style-type:none;text-align:center;font-size:2.0rem}.kb_ok{width:21%;background:#acafbe}.kb_space{width:46%;background:#fff}.kb_space:active{background:#aeb1c0}.kb_num{background:#fff}.kb_num,.number2{text-align:center;width:29%;margin:1%;padding:3% 1%;float:left;border-radius:5px;box-shadow:0 2px 1px #a0a0a0;list-style-type:none;font-size:2.0rem}.number2{background:#acafbe}.kb_num:active{background:#aeb1c0}</style>';
	html	+= '<div id="key0" class="kb_jp en"><ul class="uls"><li class="key">Q</li><li class="key">W</li><li class="key">E</li><li class="key">R</li><li class="key">T</li><li class="key">Y</li><li class="key">U</li><li class="key">I</li><li class="key">O</li><li class="key">P</li><div class="clear"></div></ul><ul class="uls ulscen"><li class="key">A</li><li class="key">S</li><li class="key">D</li><li class="key">F</li><li class="key">G</li><li class="key">H</li><li class="key">J</li><li class="key">K</li><li class="key">L</li><div class="clear"></div></ul><ul class="uls"><li class="kb_sj" id="kb_sma">小</li><li class="key">Z</li><li class="key">X</li><li class="key">C</li><li class="key">V</li><li class="key">B</li><li class="key">N</li><li class="key">M</li><li class="kb_del">←</li><div class="clear"></div></ul><ul class="uls ulscen ulbot"><li class="kb_foot kb_number">123</li><li class="kb_space">space</li><li class="kb_ok">确认</li><div class="clear"></div></ul></div>	';
	html	+= '<div id="key1" class="kb_jp en"><ul class="uls"><li class="key">q</li><li class="key">w</li><li class="key">e</li><li class="key">r</li><li class="key">t</li><li class="key">y</li><li class="key">u</li><li class="key">i</li><li class="key">o</li><li class="key">p</li><div class="clear"></div></ul><ul class="uls ulscen"><li class="key">a</li><li class="key">s</li><li class="key">d</li><li class="key">f</li><li class="key">g</li><li class="key">h</li><li class="key">j</li><li class="key">k</li><li class="key">l</li><div class="clear"></div></ul><ul class="uls"><li class="kb_sj" id="kb_big">大</li><li class="key">z</li><li class="key">x</li><li class="key">c</li><li class="key">v</li><li class="key">b</li><li class="key">n</li><li class="key">m</li><li class="kb_del">←</li><div class="clear"></div></ul><ul class="uls ulscen ulbot"><li class="kb_foot kb_number">123</li><li class="kb_space">space</li><li class="kb_ok">确认</li><div class="clear"></div></ul></div>	';
	html	+= '<div id="key2" class="kb_jp shuzi"><ul class="uls"><li class="key">1</li><li class="key">2</li><li class="key">3</li><li class="key">4</li><li class="key">5</li><li class="key">6</li><li class="key">7</li><li class="key">8</li><li class="key">9</li><li class="key">0</li><div class="clear"></div></ul><ul class="uls ulscen"><li class="key">-</li><li class="key">/</li><li class="key">:</li><li class="key">;</li><li class="key">(</li><li class="key">)</li><li class="key">$</li><li class="key">&</li><li class="key">@</li><li class="key">"</li><div class="clear"></div></ul><ul class="uls ul5"><li class="kb_sj" id="kb_teshu"># =</li><li class="key">.</li><li class="key">,</li><li class="key">?</li><li class="key">!</li><li class="key">"</li><li class="kb_del">←</li><div class="clear"></div></ul><ul class="uls ulscen ulbot"><li class="kb_foot kb_abc">abc</li><li class="kb_space">space</li><li class="kb_ok">确认</li><div class="clear"></div></ul></div>	';
	html	+= '<div id="key3" class="kb_jp zifu"><ul class="uls"><li class="key">[</li><li class="key">]</li><li class="key">{</li><li class="key">}</li><li class="key">#</li><li class="key">%</li><li class="key">^</li><li class="key">*</li><li class="key">+</li><li class="key">=</li><div class="clear"></div></ul><ul class="uls ulscen"><li class="key">_</li><li class="key">\\</li><li class="key">|</li><li class="key">~</li><li class="key">&lt;</li><li class="key">&gt;</li><li class="key">$</li><li class="key">&</li><li class="key">@</li><li class="key">"</li><div class="clear"></div></ul><ul class="uls ul5"><li class="kb_sj kb_number">123</li><li class="key">.</li><li class="key">,</li><li class="key">?</li><li class="key">!</li><li class="key">"</li><li class="kb_del">←</li><div class="clear"></div></ul><ul class="uls ulscen ulbot"><li class="kb_foot kb_abc">abc</li><li class="kb_space">space</li><li class="kb_ok">确认</li><div class="clear"></div></ul></div>	';
	html	+= '<div id="key4" class="kb_jp zifu"><ul class="uls"><li class="kb_num">1</li><li class="kb_num">2</li><li class="kb_num">3</li><div class="clear"></div></ul><ul class="uls"><li class="kb_num">4</li><li class="kb_num">5</li><li class="kb_num">6</li><div class="clear"></div></ul><ul class="uls"><li class="kb_num">7</li><li class="kb_num">8</li><li class="kb_num">9</li><div class="clear"></div></ul><ul class="uls ulscen ulbot"><li class="number2" id="kb_ok">确认</li><li class="kb_num">0</li><li class="number2 kb_del">←</li><div class="clear"></div></ul></div>';
	$('body').append(html);
	if(user){
		$(user).after('<div class="kb_co kb_c1" data-name="'+user+'" data-index="1"></div>');
	}
	if(pass){
		$(pass).after('<div class="kb_co kb_c2" data-name="'+pass+'" data-index="2"></div>');
	}
	$(".kb_co").click(function() {
		node = $(this).data('name');
		index = $(this).data('index');
		$(".kb_jp").hide();
		if (index == '1') {
			$("#key4").show();
		} else {
			$("#key1").show();
		}
	});
	$(".key,.kb_num").click(function() {
		$(node).val($(node).val() + $(this).html());
		if(window.setcode)window.setcode($(node).val());
	});
	$(".kb_space").click(function() {
		$(node).val($(node).val() + ' ');
		if(window.setcode)window.setcode($(node).val());
	});
	$(".kb_del").click(function() {
		$(node).val($(node).val().replace(/.$/,''));
		if(window.setcode)window.setcode($(node).val());
	});
	$(".kb_ok,#kb_ok").click(function() {
		$(".kb_jp").hide();
		if(window.setcode)window.setcode($(node).val());
	});
	$(".kb_abc,#kb_sma").click(function() {
		$(".kb_jp").hide();
		$("#key1").show();
		if(window.setcode)window.setcode($(node).val());
	});
	$(".kb_number").click(function() {
		$(".kb_jp").hide();
		$("#key2").show();
	});
	$("#kb_big").click(function() {
		$(".kb_jp").hide();
		$("#key0").show();
	});
	$("#kb_teshu").click(function() {
		$(".kb_jp").hide();
		$("#key3").show();
	});
}