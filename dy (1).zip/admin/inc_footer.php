	
</div>
<footer>
	<p><span>© 2016-2019</span>　<span>推荐使用 Chrome 浏览器，或使用 极速模式 </p>
</footer>
<script type="text/javascript" src="./static/jquery.min.js"></script>
<script type="text/javascript" src="./static/layer.js"></script>
<script type="text/javascript" src="./static/bootstrap.min.js"></script>
<script type="text/javascript" src="./static/admin.js"></script>
</body>
</html>
