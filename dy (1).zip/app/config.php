<?php
/*数据库配置*/
return array(
	'database' => array(
		'host' => '127.0.0.1:3306', //数据库服务器数据库端口
		'user' => 'wd', //数据库用户名
		'pass' => 'sZN4XSBpSmchpex5', //数据库密码
		'table' => 'wd', //数据库名
		'prefix' => '' //数据表前缀
	)
);
